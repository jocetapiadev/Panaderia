function enviar(){

    let nombre =document.getElementById("txt.nombre").value;
    console.log("nombre :" + nombre);
}